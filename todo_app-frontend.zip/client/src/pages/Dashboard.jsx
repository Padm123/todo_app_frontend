import { useEffect, useState } from "react";
import axios from "axios";

function Dashboard() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [editId, setEditId] = useState(null);
  const [editTitle, setEditTitle] = useState("");

  const token = localStorage.getItem("token");

  // ✅ Logout handler
  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.href = "/login";
  };

  // ✅ Fetch tasks
  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/tasks", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setTasks(res.data);
      } catch (err) {
        setMessage("Failed to load tasks ❌");
      }
    };

    fetchTasks();
  }, []);

  // ✅ Add task
  const handleAddTask = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        "http://localhost:5000/api/tasks",
        { title },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setTasks([...tasks, res.data]);
      setTitle("");
      setMessage("Task added ✅");
    } catch (err) {
      setMessage("Failed to add task ❌");
    }
  };

  // ✅ Delete task
  const handleDelete = async (taskId) => {
    try {
      await axios.delete(`http://localhost:5000/api/tasks/${taskId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTasks(tasks.filter((task) => task._id !== taskId));
      setMessage("Task deleted ✅");
    } catch (err) {
      setMessage("Failed to delete task ❌");
    }
  };

  // ✅ Start editing
  const handleEdit = (task) => {
    setEditId(task._id);
    setEditTitle(task.title);
  };

  // ✅ Submit update
  const handleUpdate = async (taskId) => {
    try {
      const res = await axios.put(
        `https://todo-app-backend-ly6b.onrender.com/api/tasks/${taskId}`,
        { title: editTitle },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const updatedTasks = tasks.map((task) =>
        task._id === taskId ? res.data : task
      );
      setTasks(updatedTasks);
      setEditId(null);
      setEditTitle("");
      setMessage("Task updated ✅");
    } catch (err) {
      setMessage("Failed to update task ❌");
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2 style={{ display: "inline-block" }}>Dashboard</h2>
      <button
        onClick={handleLogout}
        className="btn btn-outline-danger float-end"
      >
        Logout
      </button>

      <form onSubmit={handleAddTask} className="my-3 d-flex gap-2">
        <input
          className="form-control"
          type="text"
          placeholder="New task title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <button type="submit" className="btn btn-primary">
          Add Task
        </button>
      </form>

      <p>{message}</p>

      <h3>Your Tasks:</h3>
      <ul>
        {tasks.length === 0 && <li>No tasks yet</li>}
        {tasks.map((task) => (
          <li key={task._id}>
            {editId === task._id ? (
              <>
                <input
                  className="form-control d-inline-block w-50"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                />
                <button
                  className="btn btn-success btn-sm ms-2"
                  onClick={() => handleUpdate(task._id)}
                >
                  Update
                </button>
                <button
                  className="btn btn-secondary btn-sm ms-2"
                  onClick={() => setEditId(null)}
                >
                  Cancel
                </button>
              </>
            ) : (
              <>
                {task.title}
                <button
                  className="btn btn-warning btn-sm ms-3"
                  onClick={() => handleEdit(task)}
                >
                  Edit
                </button>
                <button
                  className="btn btn-danger btn-sm ms-2"
                  onClick={() => handleDelete(task._id)}
                >
                  Delete
                </button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
